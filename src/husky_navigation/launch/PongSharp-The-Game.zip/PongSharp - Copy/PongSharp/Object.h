#ifndef OBJECT_H
#define OBJECT_H
#include <iostream>
using namespace std;

int width = 500;
int height = 200;
int interval = 1000/60;

struct ball
{
	float ball_pos_x;
	float ball_pos_y;
	float ball_dir_x;
	float ball_dir_y;
	float ball_size;
	int ball_speed;
		
	ball()
	{
		ball_pos_x = width / 2; //pball.ball_pos_x (done)
		ball_pos_y = height / 2; //pball.ball_pos_y  (done)
		ball_dir_x = -1.0f; //pball.ball_dir_x (done)
		ball_dir_y = 0.0f; //pball.ball_dir_y (done)
		ball_size = 8; //pball.ball_size (done)
		ball_speed = 2; //pball.ball_speed (done)
	}
	void reset(){
		ball_size = 8; //pball.ball_size (done)
		ball_speed = 2; //pball.ball_speed (done)
	}
};

struct rackets 
{
	float r_x; 
	float r_y;
	rackets(float x, float y)
	{
		r_x = x;
		r_y = y;
	}
};

struct GameMode
{
	bool survival;
	bool normal;
	bool expert;
	bool bigHead;
	bool trippy;
	
	GameMode()
	{
		bool survival = false;
		bool normal = false;
		bool expert = false;
		bool bigHead = false;
		bool trippy = false;
	}
};

#endif