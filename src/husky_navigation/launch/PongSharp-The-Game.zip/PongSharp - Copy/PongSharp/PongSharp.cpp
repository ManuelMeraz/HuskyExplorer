#include "stdafx.h"
#include <string>
#include <windows.h>
#include <iostream>
#include <conio.h>
#include <sstream>
#include <math.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include "GL/freeglut.h"
#include <cstdlib>
#include "Object.h"
#pragma comment(lib, "OpenGL32.lib")
//Gotta define our keyboard strokes :D
#define VK_W 0x57
#define VK_S 0x53
#define VK_D 0x44
#define VK_A 0x41
#define VK_SPACE
using namespace std;


GameMode session; //session.survival session.normal session.expert session.bigHead session.trippy
bool menuLock = false;
int menuTime = 0;
int time = 0;
float PI =  3.14159265358979323846;
int score_left = 0;
int score_right = 0;
ball pball;//ball object
//default racket properties
int racket_width = 12;
int racket_height = 80;
float racket_speed = 3;
rackets left_racket(10.0f,50.0f);
//left_racket.r_x
//left_racket.r_y
rackets right_racket(width-racket_width-10, 50);
//right_racket.r_x
//right_racket.r_y

//Menu Options
bool menu;
float menu_w = 40, menu_l = 10, menu_y = height/2;
float menux[5] = {width/6,2*width/6, 3*width/6, 4*width/6, 5*width/6};
string menuText[5] = {"normal","survival","expert","bighead","trippy"};
int selector = 0;



//game controls 
void keyboard() 
{
	if(menuTime<5){
		menuLock = true;
	}else
		menuLock = false;
	if (GetAsyncKeyState(0x20)||GetAsyncKeyState(0x0D)){
		if(menu && menuLock == false){
			switch(selector){
				case 0:
					session.normal = true;
					session.survival = session.expert = session.bigHead = session.trippy = false;
					PlaySound(TEXT("boa.wav"), NULL, SND_ASYNC);
					glClearColor(0.0f,0.0f,0.0f,1);
					glColor3f(1.0f,1.0f,1.0f);
					pball.reset();
					break;
				case 1:
					session.survival = true;
					session.normal = session.expert = session.bigHead = session.trippy = false;
					PlaySound(TEXT("tiger.wav"), NULL, SND_ASYNC);
					glClearColor(0.0f,0.0f,0.0f,1);
					pball.reset();
					break;
				case 2:
					pball.reset();
					session.expert  = true;
					session.normal = session.survival = session.bigHead = session.trippy = false;
					racket_height = 40;
					pball.ball_speed=12;
					PlaySound(TEXT("bingo.wav"), NULL, SND_ASYNC);
					glClearColor(0.0f,0.0f,0.0f,1);
					racket_speed=5;
					break;
				case 3:
					session.bigHead = true;
					session.normal = session.survival = session.expert = session.trippy = false;
					PlaySound(TEXT("bass.wav"), NULL, SND_ASYNC);
					glClearColor(0.0f,0.0f,0.0f,1);
					break;
				case 4:
					session.trippy = true;
					session.normal = session.survival = session.expert = session.bigHead = false;
					pball.ball_speed=12;
					PlaySound(TEXT("bit.wav"), NULL, SND_ASYNC);
					break;
			}

			menu = false;
		}
	}
	if (GetAsyncKeyState(VK_D)||GetAsyncKeyState(VK_RIGHT)){
		if(menuLock == false){
			selector++;
			if(selector>4){
				selector = 0;
			}
			menuTime =0;
		}
	}
	if(GetAsyncKeyState(VK_A)||GetAsyncKeyState(VK_LEFT)){
		if(menuLock == false){
			selector--;
			if(selector <0){
				selector =4;
			}
			menuTime =0;
		}
	}
    // left racket controls 
	if (GetAsyncKeyState(VK_W))
	{
		if((left_racket.r_y + racket_height) < height){left_racket.r_y += racket_speed;}
		else{}//feedback here
	}
	if (GetAsyncKeyState(VK_S))
	{
		if(left_racket.r_y > 0) {left_racket.r_y -= racket_speed;}
		else{}//feedback here
	}
	if (GetAsyncKeyState(0x1B)&&GetAsyncKeyState(0x12)){glutDestroyWindow(glutGetWindow());} //ESC to exit
	if(GetAsyncKeyState(0x1B)){ //menu/pause
		if(menuLock == false){
			menu = !menu;
			menuTime =0;
		}
	}
    // right racket
	if (GetAsyncKeyState(VK_UP))
	{
		if((right_racket.r_y + racket_height) < height){right_racket.r_y += racket_speed;}
		else{}//Add feedback for hitting edge
	}
	if (GetAsyncKeyState(VK_DOWN)){
		if(right_racket.r_y > 0){right_racket.r_y -= racket_speed;}
		else{}//add feedback for hitting edge
	}
}

void vec2_norm(float& x, float &y) 
{
        // sets a vectors length to 1 (which means that x + y == 1)
        float length = sqrt((x * x) + (y * y));
        if (length != 0.0f) 
		{
			length = 1.0f / length;
            x *= length;
            y *= length;
        }
}	

//UPDATES ball movement or hits or size
void updateBall() 
{
	time+=1;
	if (session.trippy)
	{
		pball.ball_speed=10;
		srand(time);
		glColor3f(0.1f*(rand()%10),0.1f*((1+rand())%10),0.1f*((rand()-1)%10));
		pball.ball_size  = 10+45*abs(sin(float(time)*0.1));
		if(time > 465)
		{
			glClearColor(0.1f*((1+rand())%10),0.1f*(rand()%10),0.1f*((rand()-1)%10),1);
		}
	}
	pball.ball_pos_x +=pball.ball_dir_x * pball.ball_speed;
	if(session.trippy){pball.ball_pos_y +=  10*cos(float(time)*0.2)+pball.ball_dir_y * pball.ball_speed;}
	else{pball.ball_pos_y += pball.ball_dir_y * pball.ball_speed;}
    // hit by left racket
    if (pball.ball_pos_x-0.5*pball.ball_size  < left_racket.r_x + racket_width &&
        pball.ball_pos_x -0.5*pball.ball_size > left_racket.r_x &&
        pball.ball_pos_y -0.5*pball.ball_size < left_racket.r_y + racket_height &&
        pball.ball_pos_y-0.5*pball.ball_size  > left_racket.r_y) 
	{
			//Hit left racket
			Beep(550,50);
			//Big Head Mode Start
			if (session.bigHead){pball.ball_size ++;}
			//End of Big Head Mode
			
			//Survival Mode Start
			if (session.survival){
			racket_height-=1;
			racket_speed+=.1;
			}
			//Survival Mode End
			
			if (pball.ball_speed<10) pball.ball_speed+=1;
			glColor3f(1.0f, 1.0f, 0.0f);
        // set fly direction depending on where it hit the racket
        // (t is 0.5 if hit at top, 0 at center, -0.5 at bottom)
        float t = ((pball.ball_pos_y - left_racket.r_y) / racket_height) - 0.5f;
        pball.ball_dir_x = fabs(pball.ball_dir_x); // force it to be positive
        pball.ball_dir_y = t;
    }

    // hit by right racket
    if (pball.ball_pos_x+0.5*pball.ball_size  > right_racket.r_x &&
        pball.ball_pos_x+0.5*pball.ball_size  < right_racket.r_x + racket_width &&
        pball.ball_pos_y +0.5*pball.ball_size < right_racket.r_y + racket_height &&
        pball.ball_pos_y +0.5*pball.ball_size > right_racket.r_y)
	{
			//Beeping sound for the right paddle
			Beep(500,50);
			//Big Head mode start
			if (session.bigHead){pball.ball_size ++;}
			//End of Big Head mode start
			
			//Survival Mode Start
			if (session.survival)
			{
				racket_height-=1;
				racket_speed-=.1;
			}
			//Survival Mode end
			
			if (pball.ball_speed<10)pball.ball_speed+=1;
			glColor3f(1.0f, 0.0f, 1.0f);
			
        // set fly direction depending on where it hit the racket
        // (t is 0.5 if hit at top, 0 at center, -0.5 at bottom)
        float t = ((pball.ball_pos_y - right_racket.r_y) / racket_height) - 0.5f;
        pball.ball_dir_x = -fabs(pball.ball_dir_x); // force it to be negative
        pball.ball_dir_y = t;
    }

    // hit left wall
	//score
    if (pball.ball_pos_x < 0) 
	{
        ++score_right;//score
        pball.ball_pos_x = width / 2;
        pball.ball_pos_y = height / 2;
        pball.ball_dir_x = fabs(pball.ball_dir_x); // force it to be positive
        pball.ball_dir_y = 0;
		Beep(400,50);
		if (session.expert==false)
		{
			if (pball.ball_speed>4)pball.ball_speed-=2;
		}
    }

    // hit right wall
	//score
    if (pball.ball_pos_x > width) 
	{
        ++score_left;//score
        pball.ball_pos_x = width / 2;
        pball.ball_pos_y = height / 2;
        pball.ball_dir_x = -fabs(pball.ball_dir_x); // force it to be negative
        pball.ball_dir_y = 0;
		Beep(450,50);
		if (session.expert==false)
		{
			if (pball.ball_speed>4)pball.ball_speed-=2;
		}
    }

    // hit top wall
	//reflect
    if (pball.ball_pos_y > height) 
	{
		pball.ball_pos_y = height-1;
        pball.ball_dir_y = -fabs(pball.ball_dir_y); // force it to be negative
		if (session.trippy==false){Beep(600,50);}
		glColor3f(0.6f, 0.3f, 0.7f);
    }

    // hit bottom wall
	//reflect
    if (pball.ball_pos_y < 0)
	{
		pball.ball_pos_y =1;
        pball.ball_dir_y = fabs(pball.ball_dir_y); // force it to be positive
		if (session.trippy == false){Beep(600,50);}
		glColor3f(0.4f, 0.3f, 0.9f);
    }
    // make sure that length of dir stays at 1
    vec2_norm(pball.ball_dir_x, pball.ball_dir_y);
}

//draw rackets  
void drawRect(float x, float y, float width, float height) 
{
    glBegin(GL_QUADS);
    glVertex2f(x, y);
    glVertex2f(x + width, y);
    glVertex2f(x + width, y + height);
    glVertex2f(x, y + height);
    glEnd();
}

// draw the ball
void drawFilledCircle(GLfloat x, GLfloat y, GLfloat radius)
{
	int i;
	int triangleAmount = 40; //# of triangles used to draw circle
	GLfloat twicePi = 2.0f * PI; //ball radius
	
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		//draw triangles in circle
		for(i = 0; i <= triangleAmount;i++) 
		{ 
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),y + (radius * sin(i * twicePi / triangleAmount)));
		}
	glEnd();
}

//screen setup function
void enable2D(int width, int height) 
{
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0f, width, 0.0f, height, 0.0f, 1.0f);
    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity();
}

//draw score and texts
void drawText(float x, float y, std::string text)
 {
    glRasterPos2f(x, y);
    glutBitmapString(GLUT_BITMAP_8_BY_13, (const unsigned char*)text.c_str());
}

// converts int to string
std::string int2str(int x) 
{
    std::stringstream ss;
    ss << x;
    return ss.str( );
}

//draw all of our objects and screen
void draw() 
{
	menuTime++;
    // clear (has to be done at the beginning)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
	if(!menu){
	    // TODO draw our scene
		//draw rackets
		drawRect(left_racket.r_x, left_racket.r_y, racket_width, racket_height);
	    drawRect(right_racket.r_x, right_racket.r_y, racket_width, racket_height);
	    // draw score
	    drawText(width / 2 - 10, height - 15, int2str(score_left) + ":" + int2str(score_right));
		if(session.trippy){drawText(width/2-110, height-20,"TRIPPY PONG SUPER TURBO HELP DESK EDITION II.5 HD REMIX THIRD STRIKE ALPHA"); }
		//Draw the ball, BE THE BALL
		drawFilledCircle(pball.ball_pos_x - pball.ball_size  / 2, pball.ball_pos_y - pball.ball_size  / 2, pball.ball_size);
	}else{
		//drawText(menu1_x,menu_y,menu_w,menu_l);
		drawText(width / 2 - 10, height - 15, "Pause");
		for(int i = 0; i<5; i++){
			glColor3f(0.2f,0.2f,0.2f);
			drawRect(menux[i]-3,menu_y-2,menu_w,menu_l);
			if(selector == i){
				glColor3f(1.0f,0.0f,0.0f);
			}else{
				glColor3f(1.0f,1.0f,1.0f);
			}
			//drawRect(menux[i],menu_y,menu_w,menu_l);
			drawText(menux[i],menu_y,menuText[i]);
		}
		//drawText(menu1_x,menu_y,menuText[0]);
	} 

    // swap buffers (has to be done at the end)
    glutSwapBuffers();
}

//function to handle updates of ball, brackets, and screen
void update(int value) 
{
   // input handling
   keyboard();
   // update ball
   if(!menu){
	updateBall();
   }else{
	
   }
   // Call update() again in 'interval' milliseconds
   glutTimerFunc(interval, update, 0);
   // Redisplay frame
   glutPostRedisplay();
}


int main(int argc, char** argv) 
{
	int number;
    //Choose Gamemode Via text
	PlaySound(NULL, NULL, 0); 
	/*
	cout <<"Welcome to Pong#\n";
	cout <<"Enter\n 1 for Normal Mode\n 2 for Survival Mode \n 3 for Expert Mode\n 4 for BigHead mode\n 5 for Trippy Mode (Lord English)\n";
	cin >> number;
	if (number == 1|| number >5) {session.normal = true;PlaySound(TEXT("boa.wav"), NULL, SND_ASYNC);}
	else if (number ==2) {session.survival = true;PlaySound(TEXT("tiger.wav"), NULL, SND_ASYNC);}
	else if (number == 3)
	{
		session.expert  = true;
		racket_height = 40;
		pball.ball_speed=12;
		PlaySound(TEXT("bingo.wav"), NULL, SND_ASYNC);
		racket_speed=5;
	}
	else if (number ==4 ) {session.bigHead = true;PlaySound(TEXT("bass.wav"), NULL, SND_ASYNC);}
	else if (number == 5) {session.trippy = true; PlaySound(TEXT("bit.wav"), NULL, SND_ASYNC);}
	
	*/
	// initialize opengl (using glut)
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(width, height);
    /*
	if(number != 5)
	{
    	glutCreateWindow("Pong Sharp!");
		glutFullScreen();
	}
	else
	{
		glutCreateWindow("TRIPPY PONG SUPER TURBO HELP DESK EDITION II.5 HD REMIX THIRD STRIKE ALPHA");
		glutFullScreen();
	}
	*/
    // Register callback functions
    menu = true;
    glutCreateWindow("Pong Sharp!");
	glutFullScreen();
    glutDisplayFunc(draw);
    glutTimerFunc(interval, update, 0);

    // setup scene to 2d mode and set draw color to white
    enable2D(width, height);
    glColor3f(1.0f, 1.0f, 1.0f);
	
    // start the whole thing
    glutMainLoop();
    return 0;
}

