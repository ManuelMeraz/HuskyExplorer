
// Define for gcc version chec
#ifdef __GNUC__
#if (__GNUC__ == 4 && __GNUC_MINOR__ == 6)
#define GRID_UTILS_GCC_46
#endif
#endif
